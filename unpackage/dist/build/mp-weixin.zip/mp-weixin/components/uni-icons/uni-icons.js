(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["components/uni-icons/uni-icons"],{1581:function(n,t,e){"use strict";e.r(t);var u=e("7575"),r=e("d932");for(var c in r)"default"!==c&&function(n){e.d(t,n,(function(){return r[n]}))}(c);e("2042");var i,a=e("f0c5"),o=Object(a["a"])(r["default"],u["b"],u["c"],!1,null,"0962fa8d",null,!1,u["a"],i);t["default"]=o.exports},2042:function(n,t,e){"use strict";var u=e("2c74"),r=e.n(u);r.a},"2c74":function(n,t,e){},7575:function(n,t,e){"use strict";var u;e.d(t,"b",(function(){return r})),e.d(t,"c",(function(){return c})),e.d(t,"a",(function(){return u}));var r=function(){var n=this,t=n.$createElement;n._self._c},c=[]},ae34:function(n,t,e){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var u=r(e("721e"));function r(n){return n&&n.__esModule?n:{default:n}}var c={name:"UniIcons",props:{type:{type:String,default:""},color:{type:String,default:"#333333"},size:{type:[Number,String],default:16}},data:function(){return{icons:u.default}},methods:{_onClick:function(){this.$emit("click")}}};t.default=c},d932:function(n,t,e){"use strict";e.r(t);var u=e("ae34"),r=e.n(u);for(var c in u)"default"!==c&&function(n){e.d(t,n,(function(){return u[n]}))}(c);t["default"]=r.a}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'components/uni-icons/uni-icons-create-component',
    {
        'components/uni-icons/uni-icons-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("1581"))
        })
    },
    [['components/uni-icons/uni-icons-create-component']]
]);
