(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["components/uni-badge/uni-badge"],{"39e5":function(t,n,e){"use strict";e.r(n);var a=e("6b19"),u=e("4922");for(var i in u)"default"!==i&&function(t){e.d(n,t,(function(){return u[t]}))}(i);e("b21b");var r,c=e("f0c5"),o=Object(c["a"])(u["default"],a["b"],a["c"],!1,null,"89db6c9c",null,!1,a["a"],r);n["default"]=o.exports},4922:function(t,n,e){"use strict";e.r(n);var a=e("932a"),u=e.n(a);for(var i in a)"default"!==i&&function(t){e.d(n,t,(function(){return a[t]}))}(i);n["default"]=u.a},"6b19":function(t,n,e){"use strict";var a;e.d(n,"b",(function(){return u})),e.d(n,"c",(function(){return i})),e.d(n,"a",(function(){return a}));var u=function(){var t=this,n=t.$createElement;t._self._c},i=[]},"8a24":function(t,n,e){},"932a":function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var a={name:"UniBadge",props:{type:{type:String,default:"default"},inverted:{type:Boolean,default:!1},text:{type:[String,Number],default:""},size:{type:String,default:"normal"}},data:function(){return{width:"display: inline-block;width: ".concat(15*String(this.text).length+25,"rpx")}},methods:{onClick:function(){this.$emit("click")}}};n.default=a},b21b:function(t,n,e){"use strict";var a=e("8a24"),u=e.n(a);u.a}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'components/uni-badge/uni-badge-create-component',
    {
        'components/uni-badge/uni-badge-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("39e5"))
        })
    },
    [['components/uni-badge/uni-badge-create-component']]
]);
