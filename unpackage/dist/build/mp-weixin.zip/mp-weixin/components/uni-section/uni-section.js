(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["components/uni-section/uni-section"],{"302c":function(t,n,e){"use strict";var u;e.d(n,"b",(function(){return c})),e.d(n,"c",(function(){return i})),e.d(n,"a",(function(){return u}));var c=function(){var t=this,n=t.$createElement;t._self._c},i=[]},"333e":function(t,n,e){"use strict";var u=e("c9e1"),c=e.n(u);c.a},4829:function(t,n,e){"use strict";e.r(n);var u=e("302c"),c=e("7d52");for(var i in c)"default"!==i&&function(t){e.d(n,t,(function(){return c[t]}))}(i);e("333e");var r,a=e("f0c5"),o=Object(a["a"])(c["default"],u["b"],u["c"],!1,null,"ec8b8684",null,!1,u["a"],r);n["default"]=o.exports},"7d52":function(t,n,e){"use strict";e.r(n);var u=e("c0a0"),c=e.n(u);for(var i in u)"default"!==i&&function(t){e.d(n,t,(function(){return u[t]}))}(i);n["default"]=c.a},c0a0:function(t,n,e){"use strict";(function(t){Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var e={name:"UniTitle",props:{type:{type:String,default:""},title:{type:String,default:""},subTitle:{type:String,default:""}},data:function(){return{}},watch:{title:function(n){t.report&&""!==n&&t.report("title",n)}},methods:{onClick:function(){this.$emit("click")}}};n.default=e}).call(this,e("543d")["default"])},c9e1:function(t,n,e){}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'components/uni-section/uni-section-create-component',
    {
        'components/uni-section/uni-section-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("4829"))
        })
    },
    [['components/uni-section/uni-section-create-component']]
]);
